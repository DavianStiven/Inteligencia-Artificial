from typing import Dict

from fastapi import FastAPI, HTTPException
import pickle
import pandas as pd

app = FastAPI()
# para ver la documentamentación ir a la url/docs 
model_diabetes = "modelos_entrenados/model_diabetes.pkl"
model_felicidad = "modelos_entrenados/model_felicidad.pkl"
model_heart = "modelos_entrenados/model_heart.pkl"
model_price = "modelos_entrenados/model_price.pkl"

with open(model_diabetes, 'rb') as model_Diabetes:
    Model_Diabetes = pickle.load(model_Diabetes)

with open(model_felicidad, 'rb') as model_Felicidad:
    Model_Felicidad = pickle.load(model_Felicidad)

with open(model_heart, 'rb') as model_Heart:
    Model_Heart = pickle.load(model_Heart)

with open(model_price, 'rb') as model_Price:
    Model_Price = pickle.load(model_Price)


@app.get("/")
async def root():
    return {"message": "Hello World"}


@app.post("/predictDiabetes")
async def predict_diabetes(data: dict):
    try:

        features = pd.DataFrame([data])

        predict = Model_Diabetes.predict(features)
        return {"prediction": predict.tolist()}
    except Exception as e:
        print(e)
        return HTTPException(status_code=400, detail=str(e))


@app.post("/predicFelicidad")
async def predict_felicidad(data: dict):
    try:

        features = pd.DataFrame([data])

        predict = Model_Felicidad.predict(features)
        return {"prediction": predict.tolist()}
    except Exception as e:
        print(e)
        return HTTPException(status_code=400, detail=str(e))


@app.post("/predictHeart")
async def predict_heart(data: dict):
    try:
        
        features = pd.DataFrame([data])
        predict = Model_Heart.predict(features)
        return {"prediction": predict.tolist()}
    except Exception as e:
        print(e)
        return HTTPException(status_code=400, detail=str(e))
    
@app.post("/predictPrice")
async def predict_price(data:dict):
    try:
        features = pd.DataFrame([data])
        predict = Model_Price.predict(features)
        return {"prediction": predict.tolist()}
    except Exception as e:
        print(e)
        return HTTPException(status_code=400, detail=str(e))